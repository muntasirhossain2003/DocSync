// lib/features/video_call/presentation/providers/video_call_provider.dart
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/config/agora_config.dart';
import '../../data/services/agora_service.dart';
import '../../domain/models/call_state.dart';

final agoraServiceProvider = Provider<AgoraService>((ref) {
  final service = AgoraService();
  ref.onDispose(() => service.dispose());
  return service;
});

class VideoCallController extends StateNotifier<CallState> {
  final AgoraService _agoraService;
  final VideoCallInfo callInfo;

  int? _remoteUid;
  bool _isMuted = false;
  bool _isCameraEnabled = true;
  bool _isSpeakerEnabled = true;

  VideoCallController({
    required AgoraService agoraService,
    required this.callInfo,
  }) : _agoraService = agoraService,
       super(CallState.idle);

  int? get remoteUid => _remoteUid;
  bool get isMuted => _isMuted;
  bool get isCameraEnabled => _isCameraEnabled;
  bool get isSpeakerEnabled => _isSpeakerEnabled;

  Future<void> initializeCall() async {
    try {
      state = CallState.connecting;

      await _agoraService.initialize();

      // Register event handlers
      _agoraService.registerEventHandler(
        RtcEngineEventHandler(
          onJoinChannelSuccess: (RtcConnection connection, int elapsed) {
            state = CallState.connected;
          },
          onUserJoined: (RtcConnection connection, int remoteUid, int elapsed) {
            _remoteUid = remoteUid;
            state = CallState.connected;
          },
          onUserOffline:
              (
                RtcConnection connection,
                int remoteUid,
                UserOfflineReasonType reason,
              ) {
                if (_remoteUid == remoteUid) {
                  _remoteUid = null;
                  state = CallState.disconnected;
                }
              },
          onConnectionLost: (RtcConnection connection) {
            state = CallState.reconnecting;
          },
          onConnectionStateChanged:
              (
                RtcConnection connection,
                ConnectionStateType state,
                ConnectionChangedReasonType reason,
              ) {
                if (state == ConnectionStateType.connectionStateFailed) {
                  this.state = CallState.error;
                } else if (state ==
                    ConnectionStateType.connectionStateReconnecting) {
                  this.state = CallState.reconnecting;
                } else if (state ==
                    ConnectionStateType.connectionStateConnected) {
                  this.state = CallState.connected;
                }
              },
          onError: (ErrorCodeType err, String msg) {
            state = CallState.error;
          },
        ),
      );

      // Join channel with patient's user ID as uid
      await _agoraService.joinChannel(
        channelName: AgoraConfig.channelName,
        token: AgoraConfig.token,
        uid: int.parse(callInfo.patientId.hashCode.toString().substring(0, 8)),
      );
    } catch (e) {
      state = CallState.error;
      rethrow;
    }
  }

  Future<void> toggleMicrophone() async {
    _isMuted = !_isMuted;
    await _agoraService.toggleMicrophone(_isMuted);
  }

  Future<void> toggleCamera() async {
    _isCameraEnabled = !_isCameraEnabled;
    await _agoraService.toggleCamera(_isCameraEnabled);
  }

  Future<void> switchCamera() async {
    await _agoraService.switchCamera();
  }

  Future<void> endCall() async {
    await _agoraService.leaveChannel();
    state = CallState.disconnected;
  }

  RtcEngine? get engine => _agoraService.engine;
}

final videoCallControllerProvider =
    StateNotifierProvider.family<VideoCallController, CallState, VideoCallInfo>(
      (ref, callInfo) {
        final agoraService = ref.watch(agoraServiceProvider);
        return VideoCallController(
          agoraService: agoraService,
          callInfo: callInfo,
        );
      },
    );
